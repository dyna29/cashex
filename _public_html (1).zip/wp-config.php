<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u806441573_HrU0C' );

/** Database username */
define( 'DB_USER', 'u806441573_J8mA7' );

/** Database password */
define( 'DB_PASSWORD', 'cCIyOvM8On' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '=DL%xm(^I-6r%pq1q+WP:VvF]cE4cqiG2T?<%^owK>Q{{u,n`a4%^Ntp(]x^x&ew' );
define( 'SECURE_AUTH_KEY',   ' ~0w_%$O-eXbEj~a!,r{{O1/c7Oq8T>Lu}_v@Z=^19[h!hnOp8c0Wl?{E WP*Z(n' );
define( 'LOGGED_IN_KEY',     '$N1abJ>(DmeEQ=JQ0q!(Z^.jB4(n~~<#$B7?XBREVC.kOuaP9TrO:N_daYi)g8hZ' );
define( 'NONCE_KEY',         '<A>FriM]]g&Ty%P; P2.HbSI{T#USd]}}[2lg&@OoBp7+FvkwW7b?-51+GedzzZu' );
define( 'AUTH_SALT',         '22aVHvfZA:~*~Q`qIbpMgn5#-9a.`@P~89P=X3yo{oN}%;0U?Y%3[$Mh!m0xQ%3!' );
define( 'SECURE_AUTH_SALT',  'ftYcY@ImXv,ys}$hldN#Mkn}%Wf|EN_#0-C/H#zPwXj-cQT@VLo,rB325)n,~hUf' );
define( 'LOGGED_IN_SALT',    'J^2*Q0jhIc{+x/}=RFAcAO;`u/%j?gO:f?ru9rd%LzJDK^FzOy}MMTSvMa#08;b^' );
define( 'NONCE_SALT',        'N 2&Mo5A@k!$X5o% g[&OgMN;R7@pbNRc0~2f_xe5%J_C@Z}MkN?-.%~2+,Z K<Y' );
define( 'WP_CACHE_KEY_SALT', 'Jnk8VU33*wPGc|f1}y+m;s*DGttwsqVEeuJ;E59-lbp;S;y)-U/40` 5OClu{F`4' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', 'a6161faf0f2f1dd4bf6ea0751ca3c6b4' );
define( 'WP_AUTO_UPDATE_CORE', false );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
